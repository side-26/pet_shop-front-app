import { EmptyStateBoundary } from '@/components/ui/empty-state-boundary';
import { use } from 'react';
import EmptyState from './empty-state';
import Content from './content';

export default function ContentRenderer({ requestPromise }: {
    requestPromise: Promise<any>//base the api response
}) {
    const data = use(requestPromise);


    return (
        <EmptyStateBoundary data={data} isEmpty={data
            // if data is array don't change either data?.[primary-property]
        } fallback={<EmptyState />}>
            <Content data={data} />
        </EmptyStateBoundary>
    )
}
