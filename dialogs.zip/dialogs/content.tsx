import { cn } from '@/lib/utils';



type ContentProps =
  | {
      isSkeleton: true;
      data?: never;
    }
  | {
      isSkeleton?: false;
      data: any;//base the api request
    };

export default function Content({
  data,
  isSkeleton = false,
}: ContentProps) {
  return (
    <section
      className={cn(
        'customClassName',
        isSkeleton && 'skeleton',
      )}
    >
      {!isSkeleton && <div>{data.name}</div>}
    </section>
  );
}