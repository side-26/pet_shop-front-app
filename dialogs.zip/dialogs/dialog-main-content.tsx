'use server'

import { Suspense } from "react";

import ContentRenderer from './content-renderer';
import FallbackSkeleton from './content';

export default function DialogContentWrapper() {
  const promiseRequest = serverActionRequest();

  return (
    <Suspense fallback={<FallbackSkeleton isSkeleton />}>
      <ContentRenderer requestPromise={promiseRequest} />
    </Suspense>
  )
}
