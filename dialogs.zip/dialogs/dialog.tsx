import { Dialog, DialogAction, DialogClose, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogPortal, DialogTitle, DialogTrigger, dialogContentVariants } from '@/components/ui/dialog';
import { CircleXIcon } from 'lucide-react';
import { useEffect, useId, useState } from 'react';


export default function MainDialog({ onClose }: { onClose: () => void }) {
    const [isOpen, setOpen] = useState<boolean>(false);

    const id = useId();

    useEffect(() => {
        const frame = requestAnimationFrame(() => setOpen(true));

        return () => cancelAnimationFrame(frame);
    }, []);

    return (
            <Dialog open={isOpen} triggerId={id}>
                <DialogHeader>
                    {/* if have any of them */}
                    <DialogTitle>Dialog Title</DialogTitle>
                    <DialogDescription>
                        This is a description for the dialog.
                    </DialogDescription>
                    {/* if have close event */}
                    <DialogAction>
                        <CircleXIcon />
                    </DialogAction>
                </DialogHeader>
                <DialogContent size={
                    // can be 'sm' | 'md' | 'lg' | 'xl' | 'full'
                }>
                    <DialogMainContent />
                </DialogContent>
                <DialogFooter>
                    <DialogAction>
                        {/* actions */}
                    </DialogAction>
                </DialogFooter>
            </Dialog>
    )
}
