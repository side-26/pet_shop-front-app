import { Empty, EmptyDescription, EmptyHeader, EmptyMedia, EmptyTitle } from '@/components/ui/empty'


export default function EmptyState() {
    return (
        <Empty
        // can have custom-style or not base the content you use
        >
            <EmptyHeader>
                <EmptyMedia variant="icon">
                    {/* apropriate media content */}
                </EmptyMedia>
                <EmptyTitle>
                    {/* {apropriate title content} */}
                </EmptyTitle>
                <EmptyDescription>
                    {/* {apropriate deccription content} */}
                </EmptyDescription>
            </EmptyHeader>

        </Empty>
    )
}
