'use client';

import { useRef } from 'react';

import type { DialogHandle } from '@/_types';
import { useDialogController } from '@/hooks/useDialogController';

import Wrapper from './wrapper';
import Wrapper2 from './wrapper';

type UpdateOrderParams = {
    id: number;
};

export default function Usage() {
    const createDialogRef =
        useRef<DialogHandle>(null);

    const updateDialogRef =
        useRef<DialogHandle<UpdateOrderParams>>(null);

    const dialogs = useDialogController({
        createEntity: { ref: createDialogRef },
        updateEntity: { ref: updateDialogRef },
    });

    return (
        <>
            <button
                onClick={() => dialogs.open('createEntity')}
            >
                Create
            </button>

            <button
                onClick={() =>
                    dialogs.open('updateEntity', { id: 1234 })
                }
            >
                Update
            </button>

            <Wrapper ref={createDialogRef} />

            <Wrapper2 ref={updateDialogRef} />
        </>
    );
}