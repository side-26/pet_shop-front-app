import { RefObject, useImperativeHandle, useState } from 'react';

const MainDialog = dynamic(() => import('./dialog'),
    { ssr: true }//base is need seo or not
)

import { DialogHandle } from '@/_types';
import dynamic from 'next/dynamic';
import { DialogPortal } from '@/components/ui/dialog';

export default function Wrapper({ ref }:
    {
        ref: RefObject<DialogHandle | null>
    } //if have args for pass to dialog content component and show in dialog
) {

    const [isMounted, setMounted] = useState<boolean>(false);

    const open = () => {
        setMounted(true)
    }

    const close = () => {
        setMounted(false)
    }
    useImperativeHandle(ref, () => ({
        close,
        open
    }))
    return (
        <DialogPortal>
            {isMounted ? <MainDialog onClose={close} /> : null}
        </DialogPortal>
    )
}
